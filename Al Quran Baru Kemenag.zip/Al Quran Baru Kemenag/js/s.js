$(document).ready(function(){$("#s1").keyup(function(){var filter = $(this).val(), count = 0;$(".1 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s2").keyup(function(){var filter = $(this).val(), count = 0;$(".2 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s3").keyup(function(){var filter = $(this).val(), count = 0;$(".3 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s4").keyup(function(){var filter = $(this).val(), count = 0;$(".4 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s5").keyup(function(){var filter = $(this).val(), count = 0;$(".5 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s6").keyup(function(){var filter = $(this).val(), count = 0;$(".6 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s7").keyup(function(){var filter = $(this).val(), count = 0;$(".7 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s8").keyup(function(){var filter = $(this).val(), count = 0;$(".8 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s9").keyup(function(){var filter = $(this).val(), count = 0;$(".9 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s10").keyup(function(){var filter = $(this).val(), count = 0;$(".10 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s11").keyup(function(){var filter = $(this).val(), count = 0;$(".11 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s12").keyup(function(){var filter = $(this).val(), count = 0;$(".12 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s13").keyup(function(){var filter = $(this).val(), count = 0;$(".13 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s14").keyup(function(){var filter = $(this).val(), count = 0;$(".14 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s15").keyup(function(){var filter = $(this).val(), count = 0;$(".15 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s16").keyup(function(){var filter = $(this).val(), count = 0;$(".16 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s17").keyup(function(){var filter = $(this).val(), count = 0;$(".17 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s18").keyup(function(){var filter = $(this).val(), count = 0;$(".18 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s19").keyup(function(){var filter = $(this).val(), count = 0;$(".19 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s20").keyup(function(){var filter = $(this).val(), count = 0;$(".20 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s21").keyup(function(){var filter = $(this).val(), count = 0;$(".21 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s22").keyup(function(){var filter = $(this).val(), count = 0;$(".22 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s23").keyup(function(){var filter = $(this).val(), count = 0;$(".23 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s24").keyup(function(){var filter = $(this).val(), count = 0;$(".24 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s25").keyup(function(){var filter = $(this).val(), count = 0;$(".25 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s26").keyup(function(){var filter = $(this).val(), count = 0;$(".26 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s27").keyup(function(){var filter = $(this).val(), count = 0;$(".27 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s28").keyup(function(){var filter = $(this).val(), count = 0;$(".28 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s29").keyup(function(){var filter = $(this).val(), count = 0;$(".29 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s30").keyup(function(){var filter = $(this).val(), count = 0;$(".30 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s31").keyup(function(){var filter = $(this).val(), count = 0;$(".31 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s32").keyup(function(){var filter = $(this).val(), count = 0;$(".32 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s33").keyup(function(){var filter = $(this).val(), count = 0;$(".33 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s34").keyup(function(){var filter = $(this).val(), count = 0;$(".34 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s35").keyup(function(){var filter = $(this).val(), count = 0;$(".35 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s36").keyup(function(){var filter = $(this).val(), count = 0;$(".36 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s37").keyup(function(){var filter = $(this).val(), count = 0;$(".37 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s38").keyup(function(){var filter = $(this).val(), count = 0;$(".38 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s39").keyup(function(){var filter = $(this).val(), count = 0;$(".39 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s40").keyup(function(){var filter = $(this).val(), count = 0;$(".40 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s41").keyup(function(){var filter = $(this).val(), count = 0;$(".41 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s42").keyup(function(){var filter = $(this).val(), count = 0;$(".42 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s43").keyup(function(){var filter = $(this).val(), count = 0;$(".43 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s44").keyup(function(){var filter = $(this).val(), count = 0;$(".44 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s45").keyup(function(){var filter = $(this).val(), count = 0;$(".45 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s46").keyup(function(){var filter = $(this).val(), count = 0;$(".46 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s47").keyup(function(){var filter = $(this).val(), count = 0;$(".47 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s48").keyup(function(){var filter = $(this).val(), count = 0;$(".48 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s49").keyup(function(){var filter = $(this).val(), count = 0;$(".49 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s50").keyup(function(){var filter = $(this).val(), count = 0;$(".50 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s51").keyup(function(){var filter = $(this).val(), count = 0;$(".51 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s52").keyup(function(){var filter = $(this).val(), count = 0;$(".52 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s53").keyup(function(){var filter = $(this).val(), count = 0;$(".53 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s54").keyup(function(){var filter = $(this).val(), count = 0;$(".54 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s55").keyup(function(){var filter = $(this).val(), count = 0;$(".55 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s56").keyup(function(){var filter = $(this).val(), count = 0;$(".56 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s57").keyup(function(){var filter = $(this).val(), count = 0;$(".57 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s58").keyup(function(){var filter = $(this).val(), count = 0;$(".58 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s59").keyup(function(){var filter = $(this).val(), count = 0;$(".59 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s60").keyup(function(){var filter = $(this).val(), count = 0;$(".60 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s61").keyup(function(){var filter = $(this).val(), count = 0;$(".61 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s62").keyup(function(){var filter = $(this).val(), count = 0;$(".62 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s63").keyup(function(){var filter = $(this).val(), count = 0;$(".63 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s64").keyup(function(){var filter = $(this).val(), count = 0;$(".64 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s65").keyup(function(){var filter = $(this).val(), count = 0;$(".65 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s66").keyup(function(){var filter = $(this).val(), count = 0;$(".66 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s67").keyup(function(){var filter = $(this).val(), count = 0;$(".67 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s68").keyup(function(){var filter = $(this).val(), count = 0;$(".68 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s69").keyup(function(){var filter = $(this).val(), count = 0;$(".69 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s70").keyup(function(){var filter = $(this).val(), count = 0;$(".70 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s71").keyup(function(){var filter = $(this).val(), count = 0;$(".71 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s72").keyup(function(){var filter = $(this).val(), count = 0;$(".72 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s73").keyup(function(){var filter = $(this).val(), count = 0;$(".73 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s74").keyup(function(){var filter = $(this).val(), count = 0;$(".74 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s75").keyup(function(){var filter = $(this).val(), count = 0;$(".75 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s76").keyup(function(){var filter = $(this).val(), count = 0;$(".76 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s77").keyup(function(){var filter = $(this).val(), count = 0;$(".77 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s78").keyup(function(){var filter = $(this).val(), count = 0;$(".78 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s79").keyup(function(){var filter = $(this).val(), count = 0;$(".79 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s80").keyup(function(){var filter = $(this).val(), count = 0;$(".80 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s81").keyup(function(){var filter = $(this).val(), count = 0;$(".81 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s82").keyup(function(){var filter = $(this).val(), count = 0;$(".82 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s83").keyup(function(){var filter = $(this).val(), count = 0;$(".83 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s84").keyup(function(){var filter = $(this).val(), count = 0;$(".84 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s85").keyup(function(){var filter = $(this).val(), count = 0;$(".85 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s86").keyup(function(){var filter = $(this).val(), count = 0;$(".86 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s87").keyup(function(){var filter = $(this).val(), count = 0;$(".87 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s88").keyup(function(){var filter = $(this).val(), count = 0;$(".88 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s89").keyup(function(){var filter = $(this).val(), count = 0;$(".89 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s90").keyup(function(){var filter = $(this).val(), count = 0;$(".90 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s91").keyup(function(){var filter = $(this).val(), count = 0;$(".91 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s92").keyup(function(){var filter = $(this).val(), count = 0;$(".92 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s93").keyup(function(){var filter = $(this).val(), count = 0;$(".93 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s94").keyup(function(){var filter = $(this).val(), count = 0;$(".94 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s95").keyup(function(){var filter = $(this).val(), count = 0;$(".95 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s96").keyup(function(){var filter = $(this).val(), count = 0;$(".96 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s97").keyup(function(){var filter = $(this).val(), count = 0;$(".97 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s98").keyup(function(){var filter = $(this).val(), count = 0;$(".98 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s99").keyup(function(){var filter = $(this).val(), count = 0;$(".99 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s100").keyup(function(){var filter = $(this).val(), count = 0;$(".100 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s101").keyup(function(){var filter = $(this).val(), count = 0;$(".101 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s102").keyup(function(){var filter = $(this).val(), count = 0;$(".102 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s103").keyup(function(){var filter = $(this).val(), count = 0;$(".103 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s104").keyup(function(){var filter = $(this).val(), count = 0;$(".104 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s105").keyup(function(){var filter = $(this).val(), count = 0;$(".105 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s106").keyup(function(){var filter = $(this).val(), count = 0;$(".106 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s107").keyup(function(){var filter = $(this).val(), count = 0;$(".107 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s108").keyup(function(){var filter = $(this).val(), count = 0;$(".108 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s109").keyup(function(){var filter = $(this).val(), count = 0;$(".109 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s110").keyup(function(){var filter = $(this).val(), count = 0;$(".110 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s111").keyup(function(){var filter = $(this).val(), count = 0;$(".111 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s112").keyup(function(){var filter = $(this).val(), count = 0;$(".112 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s113").keyup(function(){var filter = $(this).val(), count = 0;$(".113 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});
$(document).ready(function(){$("#s114").keyup(function(){var filter = $(this).val(), count = 0;$(".114 .c").each(function(){if ($(this).text().search(new RegExp(filter, "i")) < 0) {$(this).fadeOut();} else {$(this).show();count++;}});});});



function crFunction() {
    // Declare variables
    var input, filter, ul, li, a, i;
    input = document.getElementById('myInput');
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName('li');

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}


function scrFunction() {
    // Declare variables
    var input, filter, ul, li, a, i;
    input = document.getElementById('myInput');
    filter = input.value.toUpperCase();
    ul = document.getElementById("tejaul");
    li = ul.getElementsByTagName('li');

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}


$(document).ready(function(){$('#live-search').hide();$('a#ts').click(function() {$('#live-search').toggle(0);return false;});});
	$(document).ready(function(){$('#mn').hide();$('a#tmn').click(function() {$('#mn').toggle(100);return false;});});
		$(document).ready(function(){$('#mnj').hide();$('a#tmnj').click(function() {$('#mnj').toggle(100);return false;});});

	$(document).ready(function(){$('#msc').hide();$('a#tmsc').click(function() {$('#msc').toggle(100);return false;});});
	$(document).ready(function(){$('#aya').hide();$('a#ty').click(function() {$('#aya').toggle(0);return false;});});

	
		$(document).ready(function(){$('#sag').hide();$('a#tsag').click(function() {$('#sag').toggle(0);return false;});});
	$(document).ready(function(){$('#mrs').hide();$('a#tmrs').click(function() {$('#mrs').toggle(0);return false;});});
	$(document).ready(function(){$('#abds').hide();$('a#tabds').click(function() {$('#abds').toggle(0);return false;});});

	
	$(document).ready(function(){$('#gs').hide();$('a#tg').click(function() {$('#gs').toggle(0);return false;});});
	$(document).ready(function(){$('#sgs').hide();$('a#stg').click(function() {$('#sgs').toggle(0);return false;});});

	$(document).ready(function(){$('#tos1').hide();$('a#pgs1').click(function() {$('#tos1').toggle(0);return false;});});
$(document).ready(function(){$('#tos2').hide();$('a#pgs2').click(function() {$('#tos2').toggle(0);return false;});});
$(document).ready(function(){$('#tos3').hide();$('a#pgs3').click(function() {$('#tos3').toggle(0);return false;});});
$(document).ready(function(){$('#tos4').hide();$('a#pgs4').click(function() {$('#tos4').toggle(0);return false;});});
$(document).ready(function(){$('#tos5').hide();$('a#pgs5').click(function() {$('#tos5').toggle(0);return false;});});
$(document).ready(function(){$('#tos6').hide();$('a#pgs6').click(function() {$('#tos6').toggle(0);return false;});});
$(document).ready(function(){$('#tos7').hide();$('a#pgs7').click(function() {$('#tos7').toggle(0);return false;});});
$(document).ready(function(){$('#tos8').hide();$('a#pgs8').click(function() {$('#tos8').toggle(0);return false;});});
$(document).ready(function(){$('#tos9').hide();$('a#pgs9').click(function() {$('#tos9').toggle(0);return false;});});
$(document).ready(function(){$('#tos10').hide();$('a#pgs10').click(function() {$('#tos10').toggle(0);return false;});});
$(document).ready(function(){$('#tos11').hide();$('a#pgs11').click(function() {$('#tos11').toggle(0);return false;});});
$(document).ready(function(){$('#tos12').hide();$('a#pgs12').click(function() {$('#tos12').toggle(0);return false;});});
$(document).ready(function(){$('#tos13').hide();$('a#pgs13').click(function() {$('#tos13').toggle(0);return false;});});
$(document).ready(function(){$('#tos14').hide();$('a#pgs14').click(function() {$('#tos14').toggle(0);return false;});});
$(document).ready(function(){$('#tos15').hide();$('a#pgs15').click(function() {$('#tos15').toggle(0);return false;});});
$(document).ready(function(){$('#tos16').hide();$('a#pgs16').click(function() {$('#tos16').toggle(0);return false;});});
$(document).ready(function(){$('#tos17').hide();$('a#pgs17').click(function() {$('#tos17').toggle(0);return false;});});
$(document).ready(function(){$('#tos18').hide();$('a#pgs18').click(function() {$('#tos18').toggle(0);return false;});});
$(document).ready(function(){$('#tos19').hide();$('a#pgs19').click(function() {$('#tos19').toggle(0);return false;});});
$(document).ready(function(){$('#tos20').hide();$('a#pgs20').click(function() {$('#tos20').toggle(0);return false;});});
$(document).ready(function(){$('#tos21').hide();$('a#pgs21').click(function() {$('#tos21').toggle(0);return false;});});
$(document).ready(function(){$('#tos22').hide();$('a#pgs22').click(function() {$('#tos22').toggle(0);return false;});});
$(document).ready(function(){$('#tos23').hide();$('a#pgs23').click(function() {$('#tos23').toggle(0);return false;});});
$(document).ready(function(){$('#tos24').hide();$('a#pgs24').click(function() {$('#tos24').toggle(0);return false;});});
$(document).ready(function(){$('#tos25').hide();$('a#pgs25').click(function() {$('#tos25').toggle(0);return false;});});
$(document).ready(function(){$('#tos26').hide();$('a#pgs26').click(function() {$('#tos26').toggle(0);return false;});});
$(document).ready(function(){$('#tos27').hide();$('a#pgs27').click(function() {$('#tos27').toggle(0);return false;});});
$(document).ready(function(){$('#tos28').hide();$('a#pgs28').click(function() {$('#tos28').toggle(0);return false;});});
$(document).ready(function(){$('#tos29').hide();$('a#pgs29').click(function() {$('#tos29').toggle(0);return false;});});
$(document).ready(function(){$('#tos30').hide();$('a#pgs30').click(function() {$('#tos30').toggle(0);return false;});});
$(document).ready(function(){$('#tos31').hide();$('a#pgs31').click(function() {$('#tos31').toggle(0);return false;});});
$(document).ready(function(){$('#tos32').hide();$('a#pgs32').click(function() {$('#tos32').toggle(0);return false;});});
$(document).ready(function(){$('#tos33').hide();$('a#pgs33').click(function() {$('#tos33').toggle(0);return false;});});
$(document).ready(function(){$('#tos34').hide();$('a#pgs34').click(function() {$('#tos34').toggle(0);return false;});});
$(document).ready(function(){$('#tos35').hide();$('a#pgs35').click(function() {$('#tos35').toggle(0);return false;});});
$(document).ready(function(){$('#tos36').hide();$('a#pgs36').click(function() {$('#tos36').toggle(0);return false;});});
$(document).ready(function(){$('#tos37').hide();$('a#pgs37').click(function() {$('#tos37').toggle(0);return false;});});
$(document).ready(function(){$('#tos38').hide();$('a#pgs38').click(function() {$('#tos38').toggle(0);return false;});});
$(document).ready(function(){$('#tos39').hide();$('a#pgs39').click(function() {$('#tos39').toggle(0);return false;});});
$(document).ready(function(){$('#tos40').hide();$('a#pgs40').click(function() {$('#tos40').toggle(0);return false;});});
$(document).ready(function(){$('#tos41').hide();$('a#pgs41').click(function() {$('#tos41').toggle(0);return false;});});
$(document).ready(function(){$('#tos42').hide();$('a#pgs42').click(function() {$('#tos42').toggle(0);return false;});});
$(document).ready(function(){$('#tos43').hide();$('a#pgs43').click(function() {$('#tos43').toggle(0);return false;});});
$(document).ready(function(){$('#tos44').hide();$('a#pgs44').click(function() {$('#tos44').toggle(0);return false;});});
$(document).ready(function(){$('#tos45').hide();$('a#pgs45').click(function() {$('#tos45').toggle(0);return false;});});
$(document).ready(function(){$('#tos46').hide();$('a#pgs46').click(function() {$('#tos46').toggle(0);return false;});});
$(document).ready(function(){$('#tos47').hide();$('a#pgs47').click(function() {$('#tos47').toggle(0);return false;});});
$(document).ready(function(){$('#tos48').hide();$('a#pgs48').click(function() {$('#tos48').toggle(0);return false;});});
$(document).ready(function(){$('#tos49').hide();$('a#pgs49').click(function() {$('#tos49').toggle(0);return false;});});
$(document).ready(function(){$('#tos50').hide();$('a#pgs50').click(function() {$('#tos50').toggle(0);return false;});});
$(document).ready(function(){$('#tos51').hide();$('a#pgs51').click(function() {$('#tos51').toggle(0);return false;});});
$(document).ready(function(){$('#tos52').hide();$('a#pgs52').click(function() {$('#tos52').toggle(0);return false;});});
$(document).ready(function(){$('#tos53').hide();$('a#pgs53').click(function() {$('#tos53').toggle(0);return false;});});
$(document).ready(function(){$('#tos54').hide();$('a#pgs54').click(function() {$('#tos54').toggle(0);return false;});});
$(document).ready(function(){$('#tos55').hide();$('a#pgs55').click(function() {$('#tos55').toggle(0);return false;});});
$(document).ready(function(){$('#tos56').hide();$('a#pgs56').click(function() {$('#tos56').toggle(0);return false;});});
$(document).ready(function(){$('#tos57').hide();$('a#pgs57').click(function() {$('#tos57').toggle(0);return false;});});
$(document).ready(function(){$('#tos58').hide();$('a#pgs58').click(function() {$('#tos58').toggle(0);return false;});});
$(document).ready(function(){$('#tos59').hide();$('a#pgs59').click(function() {$('#tos59').toggle(0);return false;});});
$(document).ready(function(){$('#tos60').hide();$('a#pgs60').click(function() {$('#tos60').toggle(0);return false;});});
$(document).ready(function(){$('#tos61').hide();$('a#pgs61').click(function() {$('#tos61').toggle(0);return false;});});
$(document).ready(function(){$('#tos62').hide();$('a#pgs62').click(function() {$('#tos62').toggle(0);return false;});});
$(document).ready(function(){$('#tos63').hide();$('a#pgs63').click(function() {$('#tos63').toggle(0);return false;});});
$(document).ready(function(){$('#tos64').hide();$('a#pgs64').click(function() {$('#tos64').toggle(0);return false;});});
$(document).ready(function(){$('#tos65').hide();$('a#pgs65').click(function() {$('#tos65').toggle(0);return false;});});
$(document).ready(function(){$('#tos66').hide();$('a#pgs66').click(function() {$('#tos66').toggle(0);return false;});});
$(document).ready(function(){$('#tos67').hide();$('a#pgs67').click(function() {$('#tos67').toggle(0);return false;});});
$(document).ready(function(){$('#tos68').hide();$('a#pgs68').click(function() {$('#tos68').toggle(0);return false;});});
$(document).ready(function(){$('#tos69').hide();$('a#pgs69').click(function() {$('#tos69').toggle(0);return false;});});
$(document).ready(function(){$('#tos70').hide();$('a#pgs70').click(function() {$('#tos70').toggle(0);return false;});});
$(document).ready(function(){$('#tos71').hide();$('a#pgs71').click(function() {$('#tos71').toggle(0);return false;});});
$(document).ready(function(){$('#tos72').hide();$('a#pgs72').click(function() {$('#tos72').toggle(0);return false;});});
$(document).ready(function(){$('#tos73').hide();$('a#pgs73').click(function() {$('#tos73').toggle(0);return false;});});
$(document).ready(function(){$('#tos74').hide();$('a#pgs74').click(function() {$('#tos74').toggle(0);return false;});});
$(document).ready(function(){$('#tos75').hide();$('a#pgs75').click(function() {$('#tos75').toggle(0);return false;});});
$(document).ready(function(){$('#tos76').hide();$('a#pgs76').click(function() {$('#tos76').toggle(0);return false;});});
$(document).ready(function(){$('#tos77').hide();$('a#pgs77').click(function() {$('#tos77').toggle(0);return false;});});
$(document).ready(function(){$('#tos78').hide();$('a#pgs78').click(function() {$('#tos78').toggle(0);return false;});});
$(document).ready(function(){$('#tos79').hide();$('a#pgs79').click(function() {$('#tos79').toggle(0);return false;});});
$(document).ready(function(){$('#tos80').hide();$('a#pgs80').click(function() {$('#tos80').toggle(0);return false;});});
$(document).ready(function(){$('#tos81').hide();$('a#pgs81').click(function() {$('#tos81').toggle(0);return false;});});
$(document).ready(function(){$('#tos82').hide();$('a#pgs82').click(function() {$('#tos82').toggle(0);return false;});});
$(document).ready(function(){$('#tos83').hide();$('a#pgs83').click(function() {$('#tos83').toggle(0);return false;});});
$(document).ready(function(){$('#tos84').hide();$('a#pgs84').click(function() {$('#tos84').toggle(0);return false;});});
$(document).ready(function(){$('#tos85').hide();$('a#pgs85').click(function() {$('#tos85').toggle(0);return false;});});
$(document).ready(function(){$('#tos86').hide();$('a#pgs86').click(function() {$('#tos86').toggle(0);return false;});});
$(document).ready(function(){$('#tos87').hide();$('a#pgs87').click(function() {$('#tos87').toggle(0);return false;});});
$(document).ready(function(){$('#tos88').hide();$('a#pgs88').click(function() {$('#tos88').toggle(0);return false;});});
$(document).ready(function(){$('#tos89').hide();$('a#pgs89').click(function() {$('#tos89').toggle(0);return false;});});
$(document).ready(function(){$('#tos90').hide();$('a#pgs90').click(function() {$('#tos90').toggle(0);return false;});});
$(document).ready(function(){$('#tos91').hide();$('a#pgs91').click(function() {$('#tos91').toggle(0);return false;});});
$(document).ready(function(){$('#tos92').hide();$('a#pgs92').click(function() {$('#tos92').toggle(0);return false;});});
$(document).ready(function(){$('#tos93').hide();$('a#pgs93').click(function() {$('#tos93').toggle(0);return false;});});
$(document).ready(function(){$('#tos94').hide();$('a#pgs94').click(function() {$('#tos94').toggle(0);return false;});});
$(document).ready(function(){$('#tos95').hide();$('a#pgs95').click(function() {$('#tos95').toggle(0);return false;});});
$(document).ready(function(){$('#tos96').hide();$('a#pgs96').click(function() {$('#tos96').toggle(0);return false;});});
$(document).ready(function(){$('#tos97').hide();$('a#pgs97').click(function() {$('#tos97').toggle(0);return false;});});
$(document).ready(function(){$('#tos98').hide();$('a#pgs98').click(function() {$('#tos98').toggle(0);return false;});});
$(document).ready(function(){$('#tos99').hide();$('a#pgs99').click(function() {$('#tos99').toggle(0);return false;});});
$(document).ready(function(){$('#tos100').hide();$('a#pgs100').click(function() {$('#tos100').toggle(0);return false;});});
$(document).ready(function(){$('#tos101').hide();$('a#pgs101').click(function() {$('#tos101').toggle(0);return false;});});
$(document).ready(function(){$('#tos102').hide();$('a#pgs102').click(function() {$('#tos102').toggle(0);return false;});});
$(document).ready(function(){$('#tos103').hide();$('a#pgs103').click(function() {$('#tos103').toggle(0);return false;});});
$(document).ready(function(){$('#tos104').hide();$('a#pgs104').click(function() {$('#tos104').toggle(0);return false;});});
$(document).ready(function(){$('#tos105').hide();$('a#pgs105').click(function() {$('#tos105').toggle(0);return false;});});
$(document).ready(function(){$('#tos106').hide();$('a#pgs106').click(function() {$('#tos106').toggle(0);return false;});});
$(document).ready(function(){$('#tos107').hide();$('a#pgs107').click(function() {$('#tos107').toggle(0);return false;});});
$(document).ready(function(){$('#tos108').hide();$('a#pgs108').click(function() {$('#tos108').toggle(0);return false;});});
$(document).ready(function(){$('#tos109').hide();$('a#pgs109').click(function() {$('#tos109').toggle(0);return false;});});
$(document).ready(function(){$('#tos110').hide();$('a#pgs110').click(function() {$('#tos110').toggle(0);return false;});});
$(document).ready(function(){$('#tos111').hide();$('a#pgs111').click(function() {$('#tos111').toggle(0);return false;});});
$(document).ready(function(){$('#tos112').hide();$('a#pgs112').click(function() {$('#tos112').toggle(0);return false;});});
$(document).ready(function(){$('#tos113').hide();$('a#pgs113').click(function() {$('#tos113').toggle(0);return false;});});
$(document).ready(function(){$('#tos114').hide();$('a#pgs114').click(function() {$('#tos114').toggle(0);return false;});});

var okeScrollTop = 0;
  $(window).scroll(function(event){
    var st = $(this).scrollTop();
    if (st > okeScrollTop){
    $("header").fadeOut('fast');
    } else {
    $("header").fadeIn('fast');
    }
    okeScrollTop = st;
 });

var okScrollTop = 0;
  $(window).scroll(function(event){
    var st = $(this).scrollTop();
    if (st > okScrollTop){
    $("#footer").fadeOut('fast');
    } else {
    $("#footer").fadeIn('fast');
    }
    okScrollTop = st;
 });


function myFunction() {
    var x = document.getElementsByClassName("ar");
    var i;
    for (i = 0; i < x.length; i++) {
        x[i].style.font = "25px lpmq";
		        x[i].style.lineHeight = "2";
		
				

    }
}

function tjFunction() {
    var x = document.getElementsByClassName("tj");
    var i;
    for (i = 0; i < x.length; i++) {

		if (x[i].style.display === "none") {
	        x[i].style.display = "block";
	    } else {
	        x[i].style.display = "none";
	    }

    }
}


function ltnFunction() {
    var x = document.getElementsByClassName("ltn");
    var i;
    for (i = 0; i < x.length; i++) {

		if (x[i].style.display === "none") {
	        x[i].style.display = "block";
	    } else {
	        x[i].style.display = "none";
	    }

    }
}

$(document).on('click', '.star', function () {
    var verse = $(this).closest('td').find('.stats').text();
    var isStared = this.src.indexOf('stared') > -1;
    var key = 'fvrt_quran_' + verse;

    if (isStared) {
        localStorage.removeItem(key);
        this.src = 'star.png';
    }
    else {
        localStorage.setItem(key, true);
        this.src = 'stared.png';
    }
});
 function loadJSON(ChapterSurah,callback) {   

    var xobj = new XMLHttpRequest();
        xobj.overrideMimeType("application/json");
    xobj.open('GET', ChapterSurah, true); // Replace 'my_data' with the path to your file
    xobj.onreadystatechange = function () {
          if (xobj.readyState == 4 && xobj.status == "200") {
            // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
            callback(xobj.responseText);
          }
    };
    xobj.send(null);  
 }
function loadSurah(ChapterSurah){
    var chapters = null;
    var $main = $('.main');
    var $top = $('#ok');

    var chapter = ChapterSurah;


            $.each(trans[chapter].verse, function (i, v) {
                var starIcon = 'star.png';

                var verseNumber = i.replace(/\D/g, '');

                if (localStorage.getItem('fvrt_quran_' + chapter + ':' + verseNumber)) {
                    starIcon = 'stared.png';
                }

                var text = '<div class="c">';
                text += '<div id="e">';
                text += '<j id="'+ chapter +'">';
                text += '<table width="100%">';
                text += '<td width="98%" class="frst-td">';
                text += '<n id="'+ verseNumber +'" name="'+ verseNumber +'">'+ verseNumber +'</n>';
                text += '<a class="voice_'+ chapter +'_'+ verseNumber +'" href="#"><div class="ar">'+ quran[chapter].verse[i] +'</div></a>';
                text += '<div class="ltn ltn_'+ chapter +'_'+ verseNumber +'"></div>';
                text += '<div class="tj">'+ v +'</div>';
                text += '</td>';
                text += '<td align="center">';
                text += '<div class="f-str"><span class="badge badge-primary stats">' + chapter + ':' + verseNumber + '</span><br><img class="star" src="' + starIcon + '"></div>';
                text += '</td>';
                text += '</table>';
                text += '</j>';
                text += '</div>';
                text += '</div>';

                $main.append(text);
            });

            $.each(trans[chapter].latin, function (i, l) {
                var verseNumber = i.replace(/\D/g, '');
                $('.ltn_'+ chapter +'_' + verseNumber).html(l);
            });

            $.each(trans[chapter].voice, function (i, v) {
                var verseNumber = i.replace(/\D/g, '');
                $('.voice_'+ chapter +'_' + verseNumber).attr("data-src", v);
            });

            var scriptData = '<script>$(function(){var hash = window.location.hash;if(hash){window.location.href = hash;}var e=audiojs.createAll({trackEnded:function(){var e=$("#ok .c.playing").next();if(!e.length)e=$("#ok .c").first();e.addClass("playing").siblings().removeClass("playing");t.load($("a",e).attr("data-src"));t.play()}});var t=e[0];first=$("#ok a").attr("data-src");$("#ok .c").first().addClass("playing");t.load(first);$("#ok .c").click(function(e){e.preventDefault();$(this).addClass("playing").siblings().removeClass("playing");t.load($("a",this).attr("data-src"));t.play()});$(document).keydown(function(e){var n=e.charCode?e.charCode:e.keyCode;if(n==39){var r=$(".c.playing").next();if(!r.length)r=$("#ok .c").first();r.click()}else if(n==37){var i=$(".c.playing").prev();if(!i.length)i=$("#ok .c").last();i.click()}else if(n==32){t.playPause()}})})</script>';
            $top.append(scriptData);
}

function directFavorite(chapter, verseNumber){
	window.location.href = chapter + ".html#" + verseNumber;
}
function loadFavorite(){
    var total = 0;
    var prefix = 'fvrt_quran_';
    var $main = $('.main');
    var $info = $('.info-fvrt');
    var $top = $('#ok');

    for (var i = 1; i <= 114; i++) {
        for (var j = 0; j <= 286; j++) {
            if (localStorage.getItem(prefix + i + ':' + j)) {
                total++;

                (function (chapter, verse) {
    // here, do what ever you want

                 //   $.getJSON('./json/surah/surah_' + chapter + '.json', function (quran) {
                    //    $.getJSON('./json/translation/id/id_translation_' + chapter + '.json', function (trans) {

                            $.each(trans[chapter].verse, function (i, v) {
                                var starIcon = 'star.png';

                                var verseNumber = i.replace(/\D/g, '');

                                if (localStorage.getItem('fvrt_quran_' + chapter + ':' + verseNumber)) {
                                    starIcon = 'stared.png';
                                }

                                if (verse == verseNumber) {

					                var text = '<div class="c">';
					                text += '<div id="e">';
					                text += '<j id="'+ chapter +'">';
					                text += '<table width="100%">';
					                text += '<td width="98%" class="frst-td">';
					                text += '<n>'+ verseNumber +'</n>';
					                //text += '<a class="voice_'+ chapter +'_'+ verseNumber +'" href="#"><div class="ar">'+ quran.verse[i] +'</div></a>';
					                text += '<a onclick="directFavorite('+ chapter +','+ verseNumber +')"><div class="ar">'+ quran[chapter].verse[i] +'</div></a>';
					                text += '<div class="ltn ltn_'+ chapter +'_'+ verseNumber +'"></div>';
					                text += '<div class="tj">'+ v +'</div>';
					                text += '</td>';
					                text += '<td align="center">';
					                text += '<div class="f-str"><span class="badge badge-primary stats">' + chapter + ':' + verseNumber + '</span><br><img class="star" src="' + starIcon + '"></div>';
					                text += '</td>';
					                text += '</table>';
					                text += '</j>';
					                text += '</div>';
					                text += '</div>';

                                    $info.text('Ayat Favorite (' + total + ')');
                                    $main.append(text);
                                }
                            });
				
				            $.each(trans[chapter].latin, function (i, l) {
				                var verseNumber = i.replace(/\D/g, '');

				                if (verse == verseNumber) {
					                $('.ltn_'+ chapter +'_' + verseNumber).html(l);
					            }
				            });

				            /*$.each(trans.voice, function (i, v) {
				                var verseNumber = i.replace(/\D/g, '');

				                if (verse == verseNumber) {
				                	$('.voice_'+ chapter +'_' + verseNumber).attr("data-src", v);
				                }
				            });*/

				            var scriptData = '<script>$(function(){var e=audiojs.createAll({trackEnded:function(){var e=$("#ok .c.playing").next();if(!e.length)e=$("#ok .c").first();e.addClass("playing").siblings().removeClass("playing");t.load($("a",e).attr("data-src"));t.play()}});var t=e[0];first=$("#ok a").attr("data-src");$("#ok .c").first().addClass("playing");t.load(first);$("#ok .c").click(function(e){e.preventDefault();$(this).addClass("playing").siblings().removeClass("playing");t.load($("a",this).attr("data-src"));t.play()});$(document).keydown(function(e){var n=e.charCode?e.charCode:e.keyCode;if(n==39){var r=$(".c.playing").next();if(!r.length)r=$("#ok .c").first();r.click()}else if(n==37){var i=$(".c.playing").prev();if(!i.length)i=$("#ok .c").last();i.click()}else if(n==32){t.playPause()}})})</script>';
				            $top.append(scriptData);
                   //     });
                  //  });
                })(i, j);
            }
        }
    }
}

$(document).ready(function(){$('#upd').hide();$('a#tt').click(function() {$('#upd').toggle(0);return false;});});

