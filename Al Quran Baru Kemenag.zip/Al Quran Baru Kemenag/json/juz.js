[
    {
        "index": "01",
        "start": {
            "index": "001",
            "verse": "verse_1",
            "name": "Al-Fatiha"
        },
        "end": {
            "index": "002",
            "verse": "verse_141",
            "name": "Al-Baqara"
        }
    },
    {
        "index": "02",
        "start": {
            "index": "002",
            "verse": "verse_142",
            "name": "Al-Baqara"
        },
        "end": {
            "index": "002",
            "verse": "verse_252",
            "name": "Al-Baqara"
        }
    },
    {
        "index": "03",
        "start": {
            "index": "002",
            "verse": "verse_253",
            "name": "Al-Baqara"
        },
        "end": {
            "index": "003",
            "verse": "verse_92",
            "name": "Aal-Imran"
        }
    },
    {
        "index": "04",
        "start": {
            "index": "003",
            "verse": "verse_93",
            "name": "Aal-Imran"
        },
        "end": {
            "index": "004",
            "verse": "verse_23",
            "name": "An-Nisaa'"
        }
    },
    {
        "index": "05",
        "start": {
            "index": "004",
            "verse": "verse_24",
            "name": "An-Nisaa'"
        },
        "end": {
            "index": "004",
            "verse": "verse_147",
            "name": "An-Nisaa'"
        }
    },
    {
        "index": "06",
        "start": {
            "index": "004",
            "verse": "verse_148",
            "name": "An-Nisaa'"
        },
        "end": {
            "index": "005",
            "verse": "verse_81",
            "name": "Al-Ma'ida"
        }
    },
    {
        "index": "07",
        "start": {
            "index": "005",
            "verse": "verse_82",
            "name": "Al-Ma'ida"
        },
        "end": {
            "index": "006",
            "verse": "verse_110",
            "name": "Al-An'am"
        }
    },
    {
        "index": "08",
        "start": {
            "index": "006",
            "verse": "verse_111",
            "name": "Al-An'am"
        },
        "end": {
            "index": "007",
            "verse": "verse_87",
            "name": "Al-A'raf"
        }
    },
    {
        "index": "09",
        "start": {
            "index": "007",
            "verse": "verse_88",
            "name": "Al-A'raf"
        },
        "end": {
            "index": "008",
            "verse": "verse_40",
            "name": "Al-Anfal"
        }
    },
    {
        "index": "10",
        "start": {
            "index": "008",
            "verse": "verse_41",
            "name": "Al-Anfal"
        },
        "end": {
            "index": "009",
            "verse": "verse_92",
            "name": "Al-Tawba"
        }
    },
    {
        "index": "11",
        "start": {
            "index": "009",
            "verse": "verse_93",
            "name": "Al-Tawba"
        },
        "end": {
            "index": "011",
            "verse": "verse_5",
            "name": "Hud"
        }
    },
    {
        "index": "12",
        "start": {
            "index": "011",
            "verse": "verse_6",
            "name": "Hud"
        },
        "end": {
            "index": "012",
            "verse": "verse_52",
            "name": "Yusuf"
        }
    },
    {
        "index": "13",
        "start": {
            "index": "012",
            "verse": "verse_53",
            "name": "Yusuf"
        },
        "end": {
            "index": "014",
            "verse": "verse_52",
            "name": "Ibrahim"
        }
    },
    {
        "index": "14",
        "start": {
            "index": "015",
            "verse": "verse_1",
            "name": "Al-Hijr"
        },
        "end": {
            "index": "016",
            "verse": "verse_128",
            "name": "An-Nahl"
        }
    },
    {
        "index": "15",
        "start": {
            "index": "017",
            "verse": "verse_1",
            "name": "Al-Israa"
        },
        "end": {
            "index": "018",
            "verse": "verse_74",
            "name": "Al-Kahf"
        }
    },
    {
        "index": "16",
        "start": {
            "index": "018",
            "verse": "verse_75",
            "name": "Al-Kahf"
        },
        "end": {
            "index": "020",
            "verse": "verse_135",
            "name": "Ta-Ha"
        }
    },
    {
        "index": "17",
        "start": {
            "index": "021",
            "verse": "verse_1",
            "name": "Al-Anbiya"
        },
        "end": {
            "index": "022",
            "verse": "verse_78",
            "name": "Al-Hajj"
        }
    },
    {
        "index": "18",
        "start": {
            "index": "023",
            "verse": "verse_1",
            "name": "Al-Muminun"
        },
        "end": {
            "index": "025",
            "verse": "verse_20",
            "name": "Al-Furqan"
        }
    },
    {
        "index": "19",
        "start": {
            "index": "025",
            "verse": "verse_21",
            "name": "Al-Furqan"
        },
        "end": {
            "index": "027",
            "verse": "verse_55",
            "name": "An-Naml"
        }
    },
    {
        "index": "20",
        "start": {
            "index": "027",
            "verse": "verse_56",
            "name": "An-Naml"
        },
        "end": {
            "index": "029",
            "verse": "verse_45",
            "name": "Al-Ankabut"
        }
    },
    {
        "index": "21",
        "start": {
            "index": "029",
            "verse": "verse_46",
            "name": "Al-Ankabut"
        },
        "end": {
            "index": "033",
            "verse": "verse_30",
            "name": "Al-Ahzab"
        }
    },
    {
        "index": "22",
        "start": {
            "index": "033",
            "verse": "verse_31",
            "name": "Al-Ahzab"
        },
        "end": {
            "index": "036",
            "verse": "verse_27",
            "name": "Yasin"
        }
    },
    {
        "index": "23",
        "start": {
            "index": "036",
            "verse": "verse_28",
            "name": "Yasin"
        },
        "end": {
            "index": "039",
            "verse": "verse_31",
            "name": "Az-Zumar"
        }
    },
    {
        "index": "24",
        "start": {
            "index": "039",
            "verse": "verse_32",
            "name": "Az-Zumar"
        },
        "end": {
            "index": "041",
            "verse": "verse_46",
            "name": "Fussilat"
        }
    },
    {
        "index": "25",
        "start": {
            "index": "041",
            "verse": "verse_47",
            "name": "Fussilat"
        },
        "end": {
            "index": "045",
            "verse": "verse_37",
            "name": "Al-Jathiya"
        }
    },
    {
        "index": "26",
        "start": {
            "index": "046",
            "verse": "verse_1",
            "name": "Al-Ahqaf"
        },
        "end": {
            "index": "051",
            "verse": "verse_30",
            "name": "Az-Zariyat"
        }
    },
    {
        "index": "27",
        "start": {
            "index": "051",
            "verse": "verse_31",
            "name": "Az-Zariyat"
        },
        "end": {
            "index": "057",
            "verse": "verse_29",
            "name": "Al-Hadid"
        }
    },
    {
        "index": "28",
        "start": {
            "index": "058",
            "verse": "verse_1",
            "name": "Al-Mujadilah"
        },
        "end": {
            "index": "066",
            "verse": "verse_12",
            "name": "At-Tahrim"
        }
    },
    {
        "index": "29",
        "start": {
            "index": "067",
            "verse": "verse_1",
            "name": "Al-Mulk"
        },
        "end": {
            "index": "077",
            "verse": "verse_50",
            "name": "Al-Mursalat"
        }
    },
    {
        "index": "30",
        "start": {
            "index": "078",
            "verse": "verse_1",
            "name": "An-Naba"
        },
        "end": {
            "index": "114",
            "verse": "verse_6",
            "name": "An-Nas"
        }
    }
]
